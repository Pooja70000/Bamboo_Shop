# Bamboo_Shop
1. Overview of the website without login
   
https://github.com/ananya8606/Bamboo_Shop/assets/52853286/ba403968-f429-4477-8260-d315a42484a9

2. User functionalities

https://github.com/ananya8606/Bamboo_Shop/assets/52853286/8c3ee4b1-5111-40ba-8b5f-ed19e802d5df

3. Admin functionalities
   
https://github.com/ananya8606/Bamboo_Shop/assets/52853286/0f0ed6d4-c999-4555-acb3-f87662f9c575

4. Mobile view

https://github.com/ananya8606/Bamboo_Shop/assets/52853286/6b718462-fe32-4e30-812b-fcefcac21159






