import React from 'react'
const Loading = () => {
  return (
    <div className='loader'>
      <img src='/Images/loading-gif-icon-9.jpg' alt='' />
    </div>
  )
}

export default Loading
