export const y = {
    price: {
      en: "PRICE",
      bn: "মূল্য",
      hi: "दाम",
      ne: "मुल्यांकन"
    },
    min: {
      en: "Min",
      bn: "ন্যূনতম",
      hi: "न्यूनतम",
      ne: "न्यूनतम"
    },
    max: {
      en: "Max",
      bn: "সর্বাধিক",
      hi: "अधिकतम",
      ne: "अधिकतम"
    },
  };
  