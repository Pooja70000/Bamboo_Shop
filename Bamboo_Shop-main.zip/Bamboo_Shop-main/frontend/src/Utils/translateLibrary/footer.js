export const footer = {
  copyright: {
  en: "© 2023 Copyright:",
  bn: "© ২০২৩ কপিরাইট:",
  hi: "© 2023 कॉपीराइट:",
  ne: "© २०२३ कपिराइट:"
  },
  ecomm: {
    en: "ECOMM",
    bn: "ইকম",
    hi: "ईकॉम",
    ne: "इकमर्स"
  },
 allproducts: {
  en: "Top Picks",
  bn: "সর্বাধিক পছন্দ",
  hi: "शीर्ष पसंद",
  ne: "मुख्य पसलहरू"
}
};
