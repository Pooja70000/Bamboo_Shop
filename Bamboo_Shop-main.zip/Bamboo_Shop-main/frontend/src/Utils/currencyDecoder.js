// Paypal currency decoder
export const currencyDecoder = (currency) => {
  switch (currency) {
    case 'inr':
      return 'INR'
    default:
      return 'INR'
  }
}
