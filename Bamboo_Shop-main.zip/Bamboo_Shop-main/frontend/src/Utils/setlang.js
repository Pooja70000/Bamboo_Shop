export const setLang = [
    {
        label: "English",
        lang: "en",
    },
    {
        label: "Bengali",
        lang: "bn",
    },
    {
        label: "Hindi",
        lang: "hi",
    },
    {
        label: "Nepali",
        lang: "ne",
    },
];
