export const countrySettings = [
    {
        label: "India",
        value: "in",
    },
];

export const currencySettings = [
    {
        label: "Indian Rupees (INR)",
        value: "inr",
    },
];
